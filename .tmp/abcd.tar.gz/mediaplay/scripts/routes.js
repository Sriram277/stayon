angular.module('main', ['ui.router',
  'directives.customvalidation.customValidationTypes',
  'ngAnimate',
  'angularFileUpload',
  'ngTouch',
  'ngResource',
  'ngSanitize',
  'ngCookies',
  'ngMaterial',
  'ui.calendar',
  'dndLists',
  'ui.bootstrap.datetimepicker',
  'infinite-scroll'])

.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {

if(window.sessionStorage.getItem('loggedIn')== 'true' || window.sessionStorage.getItem('loggedIn') != null){
  $urlRouterProvider.otherwise('/displays');
  $stateProvider
    // States
    .state("index", {
      url:"/index",
      //controller:'DisplayCtrl as display',
      templateUrl: "views/index.html"
    })
    .state("dashboard", {
      url:"/dashboard",
      controller: function($scope){  $scope.breadcrumb = 'dashboard'  },
      templateUrl: "views/dashboard.html"
    })
    .state("displays", {
      url:"/displays",
      controller:'DisplayCtrl as display',
      templateUrl: "views/display.html"
    })
    .state("media", {
      url:"/media",
      controller:'MediaCtrl as media',
      templateUrl: "views/media.html"
    })
    .state("widgets", {
      url:"/widgets",
      controller:'WidgetsCtrl as widgets',
      templateUrl: "views/widgets.html"
    })
    .state("campaigns", {
      url:"/campaigns",
      controller:'CampaignsCtrl as campaigns',
      templateUrl: "views/campaigns.html"
    })
    .state("scheduler", {
      url:"/scheduler",
      controller:'SchedulerCtrl as scheduler',
      templateUrl: "views/schedulers.html"
    })
}

}])
