'use strict';

/**
 * @ngdoc overview
 * @name mainApp
 * @description
 * # mainApp
 *
 * Main module of the application.
 */
var API_URL = "http://52.90.114.255:3000/";
var app = angular
    .module('mainApp', ['main','summernote','uiGmapgoogle-maps']);

app.controller('loginController', function($scope,$http,$mdToast){
    $scope.user = {};
    $scope.errorMesg = '';
     if(window.sessionStorage.getItem('loggedIn')== 'true'){
        window.location = "./index.html";
     }
    $scope.login = function(){
        $scope.loginObj = {
            "username" : $scope.user.userId,
            "password" : $scope.user.userPwd
        }
        $http.post('http://52.90.114.255:3000/users/login',$scope.loginObj).then(function(response){
            if(response.data.message === "success"){
                window.sessionStorage.setItem('loggedIn', true);
                window.location = "./index.html"
            }else {
                window.sessionStorage.setItem('loggedIn', false);
               $scope.errorMesg = response.data.data;
            }

        },function(){
            alert('Please enter valid credentials')
        });
        /*if(($scope.userId === $scope.userDetails.id) && ($scope.userPwd === $scope.userDetails.pwd)) {
            window.location = "./index.html"
        }else {
            alert('Please enter valid credentails');
        }*/
    }
})
app.factory('addEventOverRide',function(){
    return {
        newEvent: function(){ }
    }
});
app.controller('Menuctrl', function ($scope, $state, $mdMedia, $mdDialog,addEventOverRide) {
    $scope.state = $state.current.name;
    console.log($scope.state);
    angular.element('.main-menu').click(function () {
        angular.element('.main-menu').removeClass('active');
        angular.element(this).addClass('active');
    });
    $scope.logOut = function() {
        window.sessionStorage.setItem('loggedIn', false);
        window.location = "./login.html";
    }
    $scope.newEvent = function (ev) {
        //code for popup arrival on new button
        // console.log($scope.items);
        console.log("STATE--",$scope.state);
        var useFullScreen = ($mdMedia('xs')) && $scope.customFullscreen;
        if ($scope.state === "display") {
            addEventOverRide.newEvent($mdMedia,$mdDialog);
        } else if($scope.state === "campaign"){
            addEventOverRide.newEvent($mdMedia,$mdDialog);
        } else if($scope.state === "widget"){
            addEventOverRide.newEvent($mdMedia,$mdDialog);
        } else if($scope.state === "media"){
            addEventOverRide.newEvent($mdMedia,$mdDialog);


        }

    };

    $scope.breadcrumb = 'displays';
     $scope.state = "display";
    $scope.displayNavigation = function (path) {
        $scope.state = "display";
        $scope.breadcrumb = path;
        // $state.go(path);
    };
    $scope.mediaNavigation = function (path) {
        $scope.state = "media";
        $scope.breadcrumb = path;
        // $state.go(path);
    };
    $scope.widgetsNavigation = function (path) {
        $scope.state = "widget";
        $scope.breadcrumb = path;
        // $state.go(path);
    };
    $scope.campaignsNavigation = function (path) {
        $scope.state = "campaign";
        $scope.breadcrumb = path;
        // $state.go(path);
    };
    $scope.schedulerNavigation = function (path) {
        $scope.state = "schedule";
        $scope.breadcrumb = path;
        // $state.go(path);
    };

});
app.run(function ($rootScope) {
    $rootScope.$on('$locationChangeStart', function (event, nextUrl, currentUrl) {
        if(window.sessionStorage.getItem('loggedIn') == 'false' || window.sessionStorage.getItem('loggedIn') == null){
            window.location = "./login.html"
        }
        $rootScope.hideNewButton = false;
        var currLocation = nextUrl.split('#/');
        if(currLocation[1] == 'scheduler') {
            $rootScope.hideNewButton = true;
        }else {
            $rootScope.hideNewButton = false;
        }
    });
});
app.config(function ($httpProvider) {
    // Here we're adding our interceptor.
    $httpProvider.interceptors.push('httpInterceptor');
});
app.config(['$httpProvider', function ($httpProvider) {
    //Reset headers to avoid OPTIONS request (aka preflight)
    $httpProvider.defaults.headers.common = {};
    $httpProvider.defaults.headers.post = {};
    $httpProvider.defaults.headers.put = {};
    $httpProvider.defaults.headers.patch = {};
}]);
app.factory('httpInterceptor', ['$q', '$rootScope', function ($q, $rootScope) {
    $rootScope.ajaxProgress = 0;
    return {
        'request': function (config) {

            if (!config || !(config.customObj) || config.customObj.hideBlockingUi !== true) {
                $rootScope.ajaxProgress++;
            }

            //intersept your ajax calls here.
            return config || $q.when(config);
        },
        'response': function (response, config) {
            if (!(response.config.customObj) || response.config.customObj.hideBlockingUi !== true) {
                $rootScope.ajaxProgress--;
            }
            //$rootScope.ajaxProgress--;
            return response || $q.when(response);
        },
        'responseError': function (rejection, config) {
            try {
                if (!(rejection.config.customObj) || rejection.config.customObj.hideBlockingUi !== true) {
                    $rootScope.ajaxProgress--;
                }
                var error = angular.fromJson(rejection.data);
                if (error) {
                    rejection.errorReason = error.error;
                }
            } catch (err) {

            }

            return $q.reject(rejection);
        }
    };
}]);

app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

app.service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function (file, uploadUrl) {
        var fd = new FormData();
        fd.append('file', file);
        $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined
            }
        })
            .success(function () {
            })
            .error(function () {
            });
    };
}]);

app.filter('media_title',function(){
    return function(input){
        var nm = input.split('.');
        if(nm.length > 0){
            return nm[0];
        } else {
            return nm;
        }

    }
});

app.filter('media_size', function(){
    return function(input){
        var size = input;
        if (isNaN(size))
            size = 0;

        if (size < 1024)
            return size + ' Bytes';

        size /= 1024;

        if (size < 1024)
            return size.toFixed(2) + ' Kb';

        size /= 1024;

        if (size < 1024)
            return size.toFixed(2) + ' Mb';

        size /= 1024;

        if (size < 1024)
            return size.toFixed(2) + ' Gb';

        size /= 1024;

        return size.toFixed(2) + ' Tb';
    }
});

app.filter('pagination', function()
{
    return function(input, start)
    {
        start = +start;
        return input.slice(start);
    };
});
app.directive('customOnChange', function() {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var onChangeHandler = scope.$eval(attrs.customOnChange);
            element.bind('change', onChangeHandler);
        }
    };
});

app.factory("Utility", ["$rootScope", function($rootScope) {
    var videoTypes = /(\.|\/)(aepx|ale|avp|avs|bdm|bik|bin|bsf|camproj|cpi|dat|divx|dmsm|dream|dvdmedia|dvr-ms|dzm|dzp|edl|f4v|fbr|fcproject|hdmov|imovieproj|ism|ismv|m2p|m4v|mkv|mod|moi|mpeg|mts|mxf|ogv|otrkey|pds|prproj|psh|r3d|rcproject|3g2|3gp|asf|asx|avi|flv|x-flv|mov|mp4|mpg|wmv)$/i;
    var imageTypes = /(\.|\/)(jpeg|png|PNG|jpg|JPEG|JPG|bmp|BMP)$/i;
    var videoImageTypes = /(\.|\/)(jpeg|png|PNG|jpg|JPEG|JPG|bmp|BMP|aepx|ale|avp|avs|bdm|bik|bin|bsf|camproj|cpi|dat|divx|dmsm|dream|dvdmedia|dvr-ms|dzm|dzp|edl|f4v|fbr|fcproject|hdmov|imovieproj|ism|ismv|m2p|m4v|mkv|mod|moi|mpeg|mts|mxf|ogv|otrkey|pds|prproj|psh|r3d|rcproject|3g2|3gp|asf|asx|avi|flv|x-flv|mov|mp4|mpg|wmv)$/i;
    var maxVideoSize = 5243e8;
    var maxImageSize = 5243e8;
    var utilityService = {
        isEmpty: function(value) {
            if (value != undefined) {
                value = value.replace(/^\s+/, "").replace(/\s+$/, "");
                if(value === "") {
                    return true
                } else {
                    return false
                }
            } else {
                return true
            }
        },
        addDays: function(date, days) {
            var days = days;
            var myDate = new Date(date);
            console.log("inpu => ", date, " output => ", myDate);
            var to = new Date(myDate.getTime() + days * 24 * 60 * 60 * 1e3);
            return to
        },
        removeDays: function(date, days) {
            var days = days;
            var myDate = new Date(date);
            console.log("inpu => ", date, " output => ", myDate);
            var to = new Date(myDate.getTime() - days * 24 * 60 * 60 * 1e3);
            return to
        },
        validateEmail: function(email) {
            var emailRegex = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
            if (emailRegex.test(email)) {
                return true
            } else {
                return false
            }
        },
        convertLocalToUTCDate: function(date) {
            var dt = new Date(date);
            var newDt = dt.getFullYear() + "-" + (dt.getMonth() + 1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
            var utcDate = dt.getUTCFullYear() + " " + dt.getUTCMonth() + " " + dt.getUTCDate() + " " + dt.getUTCHours() + ":" + dt.getUTCMinutes() + ":" + dt.getUTCSeconds();
            console.log(utcDate);
            return utcDate
        },
        convertLocalToPHPDate: function() {
            var dt = new Date(date);
            var newDt = dt.getFullYear() + "-" + (dt.getMonth() + 1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
            return newDt
        },
        getDateDiff: function(date1, date2) {
            var one_day = 1e3 * 60 * 60 * 24;
            var date1_ms = date1.getTime();
            var date2_ms = date2.getTime();
            var difference_ms = date2_ms - date1_ms;
            return Math.round(difference_ms / one_day)
        },
        timeAMPMTO24: function(time1) {
            var time = new Date(time1);
            console.log("time = " + time);
            time = time.toString();
            var hrs = Number(time.match(/^(\d+)/)[1]);
            var mnts = Number(time.match(/:(\d+)/)[1]);
            var format = time.match(/\s(.*)$/)[1];
            if (format == "PM" && hrs < 12) hrs = hrs + 12;
            if (format == "AM" && hrs == 12) hrs = hrs - 12;
            var hours = hrs.toString();
            var minutes = mnts.toString();
            if (hrs < 10) hours = "0" + hours;
            if (mnts < 10) minutes = "0" + minutes;
            var convertedTime = hours + ":" + minutes;
            return convertedTime
        },
        time24TOAMPM: function(timestamp) {
            var dt = new Date(timestamp);
            var hrs = dt.getHours();
            var hrs1 = hrs;
            var min = "AM";
            if (hrs >= 12) {
                min = "PM";
                hrs1 = hrs1 - 12
            }
            if (hrs === 0 || hrs1 === 0) {
                hrs1 = 12
            }
            var time = hrs1 + ":" + dt.getMinutes() + " " + min;
            return time
        },
        timeAMPM: function(time) {
            var tm1 = time.split(":");
            var hrs = tm1[0];
            var hrs1 = hrs;
            var min = "AM";
            if (hrs >= 12) {
                min = "PM";
                hrs1 = hrs1 - 12
            }
            if (hrs === 0 || hrs1 === 0) {
                hrs1 = 12
            }
            var time = hrs1 + ":" + tm1[1] + " " + min;
            return time
        },
        fullTime24: function(date) {
            var dt = new Date(date);
            return dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds()
        },
        fullDate: function(date, format) {
            var dt = new Date(date);
            return dt.getFullYear() + format + (dt.getMonth() + 1) + format + dt.getDate()
        },
        getDay: function(day) {
            var dayAry = ["SUN", "MON", "TUS", "WED", "THU", "FRI", "SAT"];
            day = parseInt(day);
            if (day == 1) {
                return dayAry[0]
            }
            if (day == 2) {
                return dayAry[1]
            }
            if (day == 3) {
                return dayAry[2]
            }
            if (day == 4) {
                return dayAry[3]
            }
            if (day == 5) {
                return dayAry[4]
            }
            if (day == 6) {
                return dayAry[5]
            }
            if (day == 7) {
                return dayAry[6]
            }
        },
        fullMonth: function(month) {
            var monthsAry = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
            month = parseInt(month);
            if (month == 1) {
                return monthsAry[0]
            }
            if (month == 2) {
                return monthsAry[1]
            }
            if (month == 3) {
                return monthsAry[2]
            }
            if (month == 4) {
                return monthsAry[3]
            }
            if (month == 5) {
                return monthsAry[4]
            }
            if (month == 6) {
                return monthsAry[5]
            }
            if (month == 7) {
                return monthsAry[6]
            }
            if (month == 8) {
                return monthsAry[7]
            }
            if (month == 9) {
                return monthsAry[8]
            }
            if (month == 10) {
                return monthsAry[9]
            }
            if (month == 11) {
                return monthsAry[10]
            }
            if (month == 12) {
                return monthsAry[11]
            }
        },
        objectToRequestData: function(item) {
            console.log(item);
            var form_data = "";
            for (var key in item) {
                form_data = form_data + key + "=" + item[key] + "&"
            }
            console.log(form_data);
            return form_data.slice(0, -1)
        },
        isObjectEmpty: function(obj) {
            for (var i in obj)
                if (obj.hasOwnProperty(i)) return false;
            return true
        },
        validateVideo: function(files) {
            var videoSize = maxVideoSize;
            var data = {
                files: [files]
            };
            var lnt = data.files.length;
            console.log(lnt);
            console.log(data);
            var returnvl = {
                val: false,
                error: "format"
            };
            for (var i = 0; i < lnt; i++) {
                var type1 = data.files[i].name;
                var type2 = type1.split(".");
                var type = "." + type2[type2.length - 1];
                console.log(type);
                var size = data.files[i].size;
                if (size <= videoSize) {
                    if (videoTypes.test(type)) {
                        returnvl.val = true
                    } else {
                        i = lnt;
                        returnvl.val = false
                    }
                } else {
                    returnvl.val = false;
                    returnvl.error = "size"
                }
            }
            console.log(returnvl);
            return returnvl
        },
        validateImage: function(files) {
            var imageSize = maxImageSize;
            var data = {
                files: [files]
            };
            var lnt = data.files.length;
            console.log(lnt);
            console.log(data);
            var returnvl = {
                val: false,
                error: "format"
            };
            for (var i = 0; i < lnt; i++) {
                var type1 = data.files[i].name;
                var type2 = type1.split(".");
                var type = "." + type2[type2.length - 1];
                console.log(type);
                var size = data.files[i].size;
                if (size <= imageSize) {
                    if (imageTypes.test(type)) {
                        returnvl.val = true
                    } else {
                        i = lnt;
                        returnvl.val = false
                    }
                } else {
                    returnvl.val = false;
                    returnvl.error = "size"
                }
            }
            console.log(returnvl);
            return returnvl
        },
        validateVideosImages: function(files) {
            var videoSize = maxVideoSize;
            var data = {
                files: [files]
            };
            var lnt = data.files.length;
            console.log(lnt);
            console.log(data);
            var returnvl = {
                val: false,
                error: "format"
            };
            for (var i = 0; i < lnt; i++) {
                var type1 = data.files[i].name;
                var type2 = type1.split(".");
                var type = "." + type2[type2.length - 1];
                console.log(type);
                var size = data.files[i].size;
                if (size <= videoSize) {
                    if (videoImageTypes.test(type)) {
                        returnvl.val = true
                    } else {
                        i = lnt;
                        returnvl.val = false
                    }
                } else {
                    returnvl.val = false;
                    returnvl.error = "size"
                }
            }
            console.log(returnvl);
            return returnvl
        },
        checkObjectKey: function(obj, key, defaultValue, value) {
            if (value == undefined) {
                value = obj[key]
            }
            return obj.hasOwnProperty(key) ? value : defaultValue
        },
        getQueryStringData: function(name) {
            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                results = regex.exec(location.search);
            return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "))
        },
        getUtcDate: function(offset) {
            var utcOffset = new Date((new Date).getTime() + offset * 3600 * 1e3).toUTCString().replace(/ GMT$/, "");
            var endDate = new Date(utcOffset);
            var sdt = endDate.getDate();
            var smt = endDate.getMonth() + 1;
            if (sdt < 10) {
                sdt = "0" + sdt
            }
            if (smt < 10) {
                smt = "0" + smt
            }
            var date1 = endDate.getFullYear() + "/" + smt + "/" + sdt;
            var date2 = sdt + "/" + smt + "/" + endDate.getFullYear();
            return {
                date1: date1,
                date2: date2
            }
        },
        getUtcStartDate: function(strtDate) {
            var startDate = UtilityService.removeDays(strtDate, 7);
            var edt = startDate.getDate();
            var emt = startDate.getMonth() + 1;
            if (edt < 10) {
                edt = "0" + edt
            }
            if (emt < 10) {
                emt = "0" + emt
            }
            var date1 = startDate.getFullYear() + "/" + emt + "/" + edt;
            var date2 = edt + "/" + emt + "/" + startDate.getFullYear();
            return {
                date1: date1,
                date2: date2
            }
        },
        calculateTimeZone: function(timeZone) {
            var dateRange = {
                startDate: "",
                endDate: "",
                currDate: "" + " -  " + ""
            };
            if (!this.isEmpty(timeZone)) {
                console.log("timeZone", timeZone);
                var offset = timeZone.split("UTC");
                var utcoffset = offset[1].replace(new RegExp(":", "g"), ".");
                var endDate = this.getUtcDate(utcoffset);
                var startDate = this.getUtcStartDate(endDate.date1);
                dateRange = {
                    startDate: startDate.date1,
                    endDate: endDate.date1,
                    currDate: startDate.date2 + " -  " + endDate.date2
                }
            }
            return dateRange
        },
        cleanArray: function(actual) {
            var newArray = [];
            for (var i = 0; i < actual.length; i++) {
                if (actual[i]) {
                    newArray.push(actual[i]);
                }
            }
            return newArray;
        }

};
    return utilityService
}]);
